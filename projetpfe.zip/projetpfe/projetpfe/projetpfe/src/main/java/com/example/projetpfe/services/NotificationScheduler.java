package com.example.projetpfe.services;

import com.example.projetpfe.entity.User;
import com.example.projetpfe.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import jakarta.mail.MessagingException;
import java.util.List;

@Component
public class NotificationScheduler {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EmailService emailService;

    // Run on the first day of every month at 9 AM
    @Scheduled(cron = "0 0 9 1 * ?")
    public void sendManualEntryReminders() {
        List<User> users = userRepository.findAll();
        for (User user : users) {
            try {
                emailService.sendManualEntryReminder(user.getEmail(), user.getUsername());
            } catch (MessagingException e) {
                System.err.println("Failed to send reminder to " + user.getEmail() + ": " + e.getMessage());
            }
        }
    }
}