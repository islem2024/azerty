package com.example.projetpfe.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    public void sendEmail(String to, String subject, String body) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);

        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(body, true); // true indicates HTML content

        mailSender.send(message);
    }

    // Send reminder for manual entry
    public void sendManualEntryReminder(String to, String userName) throws MessagingException {
        String subject = "Rappel : Saisie de vos relevés de consommation";
        String body = String.format("""
            <h3>Bonjour %s,</h3>
            <p>Il est temps de saisir vos relevés manuels de consommation d'eau et d'énergie pour ce mois.</p>
            <p>Connectez-vous à votre compte pour mettre à jour vos données :</p>
            
            <p>Merci de votre attention !</p>
            <p>Ecosuivi</p>
            """, userName);
        sendEmail(to, subject, body);
    }

    // Send overconsumption alert
    public void sendOverconsumptionAlert(String to, String userName, String type, double value, double threshold) throws MessagingException {
        String subject = String.format("Alerte : Surconsommation de %s détectée", type);
        String body = String.format("""
            <h3>Bonjour %s,</h3>
            <p>Nous avons détecté une surconsommation de %s dans vos relevés.</p>
            <p>Valeur mesurée : %.2f %s (Seuil : %.2f %s)</p>
            <p>Veuillez vérifier vos équipements ou consulter nos conseils d'économie :</p>
          
            <p>Ecosuivi</p>
            """, userName, type, value, type.equals("eau") ? "litres" : "kWh", threshold, type.equals("eau") ? "litres" : "kWh");
        sendEmail(to, subject, body);
    }

    // Send saving tips
    public void sendSavingTips(String to, String userName, String type) throws MessagingException {
        String subject = String.format("Conseils pour économiser votre %s", type);
        String body = String.format("""
            <h3>Bonjour %s,</h3>
            <p>Voici quelques conseils pour réduire votre consommation de %s :</p>
            <ul>
                <li>%s</li>
                <li>%s</li>
                <li>%s</li>
            </ul>
         
            <p>Ecosuivi</p>
            """, userName, type,
                type.equals("eau") ? "Réparez les fuites rapidement." : "Éteignez les appareils en veille.",
                type.equals("eau") ? "Utilisez des pommeaux de douche à faible débit." : "Optez pour des ampoules LED.",
                type.equals("eau") ? "Préférez les lavages à pleine charge." : "Réglez votre thermostat intelligemment.");
        sendEmail(to, subject, body);
    }


    public void sendPasswordResetEmail(String to, String userName, String resetCode) throws MessagingException {
        String subject = "Réinitialisation de votre mot de passe";
        String body = String.format("""
            <h3>Bonjour %s,</h3>
            <p>Vous avez demandé à réinitialiser votre mot de passe.</p>
            <p>Utilisez le code suivant dans l'application pour réinitialiser votre mot de passe :</p>
            <h2>%s</h2>
            <p>Ce code est valide pendant 1 heure.</p>
            <p>Si vous n'avez pas fait cette demande, ignorez cet email.</p>
            <p>Ecosuivi</p>
            """, userName, resetCode);
        sendEmail(to, subject, body);
    }


}