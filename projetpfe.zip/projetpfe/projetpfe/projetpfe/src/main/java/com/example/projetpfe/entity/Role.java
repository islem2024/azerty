package com.example.projetpfe.entity;

public enum Role {
    USER,
    ADMIN,
}
