package com.example.projetpfe.auth;

import com.example.projetpfe.entity.Role;
import com.example.projetpfe.entity.User;
import com.example.projetpfe.repository.UserRepository;
import com.example.projetpfe.config.JwtService;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.example.projetpfe.services.EmailService;

import java.security.SecureRandom;
import java.util.Date;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final UserRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;
    private final EmailService emailService;

    public AuthenticationResponse register(RegisterRequest request) {
        var user = User.builder()
                .userName(request.getUserName())
                .email(request.getEmail())
                .address(request.getAddress())
                .phoneNumber(request.getPhoneNumber())
                .nombreOccupant(request.getNombreOccupant())
                .typeLogement(request.getTypeLogement())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.USER)
                .build();
        repository.save(user);
        var jwtToken = jwtService.generateToken(user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()
                )
        );

        var user = repository.findByEmail(request.getEmail())
                .orElseThrow();
        var jwtToken = jwtService.generateToken(user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }





    public AuthenticationResponse requestPasswordReset(String email) {
        User user = repository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        // Generate a 6-digit reset code
        String resetCode = generateResetCode();
        // Set expiration to 1 hour from now
        Date expiration = new Date(System.currentTimeMillis() + 3600 * 1000);

        // Save reset code and expiration to user
        user.setResetCode(resetCode);
        user.setResetCodeExpiration(expiration);
        repository.save(user);

        try {
            emailService.sendPasswordResetEmail(user.getEmail(), user.getUsername(), resetCode);
        } catch (MessagingException e) {
            throw new RuntimeException("Erreur lors de l'envoi de l'email de réinitialisation");
        }

        return AuthenticationResponse.builder()
                .token(resetCode) // Return reset code for testing purposes
                .build();
    }

    public void resetPassword(String email, String resetCode, String newPassword) {
        User user = repository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

        // Validate reset code
        if (user.getResetCode() == null || !user.getResetCode().equals(resetCode)) {
            throw new RuntimeException("Code de réinitialisation invalide");
        }

        // Check expiration
        if (user.getResetCodeExpiration() == null || user.getResetCodeExpiration().before(new Date())) {
            throw new RuntimeException("Code de réinitialisation expiré");
        }

        // Update password and clear reset code
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setResetCode(null);
        user.setResetCodeExpiration(null);
        repository.save(user);
    }

    private String generateResetCode() {
        SecureRandom random = new SecureRandom();
        int code = 100000 + random.nextInt(900000); // Generate 6-digit code
        return String.valueOf(code);
    }
}