package com.example.projetpfe.controllers;

import com.example.projetpfe.config.JwtService;
import com.example.projetpfe.entity.UpdateProfileRequest;
import com.example.projetpfe.entity.User;
import com.example.projetpfe.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8100")
@RequestMapping("/api/users")
@RestController

public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private JwtService jwtService;
    private static final String SECRET_KEY = "1236F90B14E7FEC69C695FF165EF028D66984B83B302C27D4A2F17F2A20AA262";

    @GetMapping("/")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/profile/{id}")
    public User getUser(@PathVariable Long id) {
        return userService.getUserById(id);
    }


    @PostMapping("/")
    public User addUser(@RequestBody User user) {
        return userService.addUser(user);
    }

    @PutMapping("/{userId}")
    @PreAuthorize("hasRole('ADMIN') or #userId == authentication.principal.id")
    public ResponseEntity<User> updateUser(@PathVariable Long userId, @RequestBody User updatedUserInfo) {
        User updatedUser = userService.updateUser(userId, updatedUserInfo);
        return ResponseEntity.ok(updatedUser);
    }


    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or #id == authentication.principal.id")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "User deleted successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to delete user: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @PostMapping("/profile/image")
    public ResponseEntity<?> uploadProfileImage(
            @RequestHeader("Authorization") String token,
            @RequestParam("file") MultipartFile file) {
        try {
            String jwtToken = token.substring(7);
            String email = jwtService.extractUsername(jwtToken);
            User existingUser = userService.findByEmail(email);

            if (!jwtService.isTokenValid(jwtToken, existingUser)) {
                return ResponseEntity.badRequest().body("Erreur d'authentification : Token invalide");
            }

            User updatedUser = userService.uploadProfileImage(email, file);
            return ResponseEntity.ok(updatedUser);
        } catch (IOException e) {
            return ResponseEntity.badRequest().body("Erreur lors de l'upload de l'image : " + e.getMessage());
        }
    }
}
