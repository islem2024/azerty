package com.example.projetpfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ProjetpfeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetpfeApplication.class, args);
	}

}
