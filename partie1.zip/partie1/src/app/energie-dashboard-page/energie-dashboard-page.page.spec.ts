import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EnergieDashboardPagePage } from './energie-dashboard-page.page';

describe('EnergieDashboardPagePage', () => {
  let component: EnergieDashboardPagePage;
  let fixture: ComponentFixture<EnergieDashboardPagePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(EnergieDashboardPagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
