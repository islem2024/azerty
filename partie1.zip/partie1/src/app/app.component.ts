import { Component } from '@angular/core';
import { IonApp, IonRouterOutlet, IonHeader, IonToolbar, IonButtons } from '@ionic/angular/standalone';
import { SettingsService } from './services/SettingsService';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  imports: [ IonApp, IonRouterOutlet],
})
export class AppComponent {
  constructor(private settingsService: SettingsService) {}

  ngOnInit() {
    // Apply dark mode based on stored settings
    this.settingsService.getSettings().subscribe(settings => {
      if (settings.darkMode) {
        document.body.classList.add('dark');
      } else {
        document.body.classList.remove('dark');
      }
    });
  }
}
