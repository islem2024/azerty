import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule, ToastController } from '@ionic/angular';
import { ConsommationEauService, ConsommationEau } from '../services/ConsommationEauService';
import { AuthService } from '../services/auth.services';
import { HttpClientModule } from '@angular/common/http';
import { addIcons } from 'ionicons';
import { waterOutline } from 'ionicons/icons';
import { SettingsService } from '../services/SettingsService';

@Component({
  selector: 'app-historique-eau-page',
  templateUrl: './historique-eau-page.page.html',
  styleUrls: ['./historique-eau-page.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule,
    HttpClientModule
  ],
  providers: [ConsommationEauService, AuthService,SettingsService]
})
export class HistoriqueEauPagePage implements OnInit {

  consommations: ConsommationEau[] = [];
  isLoading = false;
  waterUnit: string = 'litres'; // Default unit

  constructor(
    private consommationService: ConsommationEauService,
    private authService: AuthService,
    private settingsService: SettingsService,
    private toastController: ToastController
  ) {
    addIcons({ 'water-outline': waterOutline });
  }

  ngOnInit() {
    // Load water unit from settings
    this.settingsService.getSettings().subscribe(settings => {
      this.waterUnit = settings.waterUnit || 'litres';
      // Reload consumptions to apply unit conversion
      this.loadConsommations();
    });
  }

  loadConsommations() {
    this.isLoading = true;
    const token = this.authService.getToken();
    if (!token) {
      this.isLoading = false;
      this.presentToast('Veuillez vous connecter.', 'danger');
      this.authService.logout();
      return;
    }

    this.consommationService.getAllConsommations().subscribe({
      next: (data: ConsommationEau[]) => {
        this.consommations = data
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
          .map(consommation => ({
            ...consommation,
            value: this.waterUnit === 'm3' ? consommation.value / 1000 : consommation.value
          }));
        this.isLoading = false;
      },
      error: (error) => {
        this.isLoading = false;
        let errorMessage = 'Erreur lors du chargement des données.';
        if (error.status === 403) {
          errorMessage = 'Accès refusé. Veuillez vous reconnecter.';
          this.authService.logout();
        } else if (error.status === 0) {
          errorMessage = 'Erreur de connexion au serveur.';
        }
        this.presentToast(errorMessage, 'danger');
        console.error('Erreur:', error);
      }
    });
  }

  refresh(event: CustomEvent<{ complete: () => void }>) {
    this.loadConsommations();
    setTimeout(() => {
      event.detail.complete();
    }, 500);
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      duration: 2000,
      color,
      position: 'bottom'
    });
    await toast.present();
  }
}