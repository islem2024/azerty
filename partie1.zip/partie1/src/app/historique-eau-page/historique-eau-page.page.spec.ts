import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HistoriqueEauPagePage } from './historique-eau-page.page';

describe('HistoriqueEauPagePage', () => {
  let component: HistoriqueEauPagePage;
  let fixture: ComponentFixture<HistoriqueEauPagePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoriqueEauPagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
