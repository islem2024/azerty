
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private token = new BehaviorSubject<string | null>(null);
  private apiUrl = 'http://localhost:8081/api/v1/auth';
  private jwtHelper: JwtHelperService = new JwtHelperService();
  
  constructor(private http: HttpClient, private router: Router) {
    // Try to load token from localStorage on service initialization
    const storedToken = localStorage.getItem('token');
    if (storedToken) {
      const isExpired = this.jwtHelper.isTokenExpired(storedToken);
      if (!isExpired) {
        this.token.next(storedToken);
      } else {
        this.logout();
      }
    }
  }

  login(email: string, password: string): Observable<{ token: string }> {
    return this.http.post<{ token: string }>(`${this.apiUrl}/authenticate`, { email, password })
      .pipe(
        tap(response => {
          console.log('Réponse login:', response);
          if (response.token) {
            this.token.next(response.token);
            localStorage.setItem('token', response.token);
            const decoded = this.jwtHelper.decodeToken(response.token);
            console.log('Token décodé après login:', decoded);
          } else {
            throw new Error('Token non reçu');
          }
        })
      );
  }

  register(
    email: string,
    password: string,
    userName: string,
    phoneNumber: number,
    address: string,
    nombreOccupant: number,
    typeLogement: string
  ): Observable<{ token: string }> {
    return this.http.post<{ token: string }>(`${this.apiUrl}/register`, {
      email,
      password,
      userName,
      phoneNumber,
      address,
      nombreOccupant,
      typeLogement
    }).pipe(
      tap(response => {
        console.log('Réponse register:', response);
        if (response.token) {
          this.token.next(response.token);
          localStorage.setItem('token', response.token);
          const decoded = this.jwtHelper.decodeToken(response.token);
          console.log('Token décodé après register:', decoded);
        } else {
          console.error('Aucun token dans la réponse de register');
          throw new Error('Token non reçu après inscription');
        }
      })
    );
  }

  getToken(): string | null {
    const token = this.token.value || localStorage.getItem('token');
    console.log('Valeur de getToken:', token);
    return token;
  }

  logout() {
    this.token.next(null);
    localStorage.removeItem('token');
    this.router.navigate(['/loginpage']);
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }
    try {
      const isExpired = this.jwtHelper.isTokenExpired(token);
      return !isExpired;
    } catch (error) {
      console.error('Erreur lors de la vérification du token:', error);
      return false;
    }
  }

  getCurrentUserId(): number | null {
    const token = this.getToken();
    if (token) {
      try {
        const decodedToken = this.jwtHelper.decodeToken(token);
        console.log('Decoded Token:', decodedToken);
        
        // Check for various possible ID fields in the token
        const userId = decodedToken.id || decodedToken.userId || decodedToken.sub;
        
        if (userId) {
          return typeof userId === 'number' ? userId : Number(userId);
        }
        console.error('ID non trouvé dans le token');
        return null;
      } catch (error) {
        console.error('Erreur lors du décodage du token:', error);
        return null;
      }
    }
    console.error('Aucun token trouvé');
    return null;
  }
  
  validateToken(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }
    
    try {
      const decoded = this.jwtHelper.decodeToken(token);
      const currentTimestamp = Math.floor(Date.now() / 1000);
      const isExpired = decoded.exp < currentTimestamp;
      
      if (isExpired) {
        this.logout();
        return false;
      }
      
      return true;
    } catch (error) {
      console.error('Erreur de validation du token:', error);
      this.logout();
      return false;
    }
  }


  getUserId(): string | null {
    const token = this.getToken();
    if (token) {
      try {
        const decoded = this.jwtHelper.decodeToken(token);
        const userId = decoded?.id || decoded?.userId || decoded?.sub || null;
        if (userId && !isNaN(Number(userId))) {
          console.log('Decoded userId:', userId);
          return userId.toString();
        } else {
          console.error('Invalid userId in JWT:', decoded);
          return null;
        }
      } catch (error) {
        console.error('Error decoding JWT:', error);
        return null;
      }
    }
    return null;
  }



  requestPasswordReset(email: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/forgot-password`, { email });
  }

  resetPassword(email: string, resetCode: string, newPassword: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/reset-password`, { email, resetCode, newPassword });
  }

}
  