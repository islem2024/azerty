// import { Injectable } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class SettingsService {
//   private settingsSubject = new BehaviorSubject<any>({
//     darkMode: false,
//     waterUnit: 'litres', // Default unit for water
//     energyUnit: 'kWh',   // Default unit for energy
//     waterThreshold: 100,
//     energyThreshold: 10
//   });
//   private settingsKey = 'app_settings';

//   constructor() {
//     // Load settings from local storage
//     const savedSettings = localStorage.getItem(this.settingsKey);
//     if (savedSettings) {
//       this.settingsSubject.next(JSON.parse(savedSettings));
//     }
//   }

//   // Get settings as an observable
//   getSettings() {
//     return this.settingsSubject.asObservable();
//   }

//   // Get current settings value
//   getCurrentSettings() {
//     return this.settingsSubject.getValue();
//   }

//   // Save settings
//   saveSettings(settings: any) {
//     localStorage.setItem(this.settingsKey, JSON.stringify(settings));
//     this.settingsSubject.next(settings);
//   }
// }
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

// Define the settings interface for type safety
export interface AppSettings {
  darkMode: boolean;
  waterUnit: string;
  energyUnit: string;
  waterThreshold: number;
  energyThreshold: number;
  notifications: {
    manualEntryReminders: boolean;
    overconsumptionAlerts: boolean;
    savingTips: boolean;
  };
}

@Injectable({
  providedIn: 'root'
})
export class SettingsService {
  private defaultSettings: AppSettings = {
    darkMode: false,
    waterUnit: 'litres',
    energyUnit: 'kWh',
    waterThreshold: 100,
    energyThreshold: 10,
    notifications: {
      manualEntryReminders: true,
      overconsumptionAlerts: true,
      savingTips: true
    }
  };

  private settingsSubject = new BehaviorSubject<AppSettings>(this.defaultSettings);
  private settingsKey = 'app_settings';

  constructor() {
    const savedSettings = localStorage.getItem(this.settingsKey);
    if (savedSettings) {
      const parsedSettings = JSON.parse(savedSettings);
      // Merge default settings with saved settings to ensure all properties exist
      const mergedSettings: AppSettings = {
        ...this.defaultSettings,
        ...parsedSettings,
        notifications: {
          ...this.defaultSettings.notifications,
          ...parsedSettings?.notifications // Safely merge notifications
        }
      };
      this.settingsSubject.next(mergedSettings);
    }
  }

  getSettings() {
    return this.settingsSubject.asObservable();
  }

  getCurrentSettings(): AppSettings {
    return this.settingsSubject.getValue();
  }

  saveSettings(settings: AppSettings) {
    localStorage.setItem(this.settingsKey, JSON.stringify(settings));
    this.settingsSubject.next(settings);
  }
}