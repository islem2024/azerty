
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.services';

export interface ConsommationEnergie {
  id: number;
  value: number;
  prix: number;
  category: string;
  date: string;
  notes?: string;
  user?: { id: number };
}

@Injectable({
  providedIn: 'root'
})
export class ConsommationEnergieService {
  private apiUrl = 'http://localhost:8081/api/consommation-energie';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': token ? `Bearer ${token}` : ''
    });
  }

  addConsommationEnergie(consommation: any): Observable<ConsommationEnergie> {
    if (!consommation.userId) {
      console.error('Attention: userId manquant dans les données de consommation!');
    }
    return this.http.post<ConsommationEnergie>(this.apiUrl, consommation, { headers: this.getHeaders() });
  }

  // Update other methods similarly if needed
  getAllConsommations(): Observable<ConsommationEnergie[]> {
    return this.http.get<ConsommationEnergie[]>(this.apiUrl, { headers: this.getHeaders() });
  }

  getConsommationById(id: number): Observable<ConsommationEnergie> {
    return this.http.get<ConsommationEnergie>(`${this.apiUrl}/${id}`, { headers: this.getHeaders() });
  }

  updateConsommationEnergie(id: number, consommation: any): Observable<ConsommationEnergie> {
    return this.http.put<ConsommationEnergie>(`${this.apiUrl}/${id}`, consommation, { headers: this.getHeaders() });
  }

  deleteConsommationEnergie(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`, { headers: this.getHeaders() });
  }
  getStats(period: string, startDate: string, endDate: string): Observable<any> {
    const params = { period, startDate, endDate };
    return this.http.get<any>(`${this.apiUrl}/stats`, { headers: this.getHeaders(), params });
  }
}

