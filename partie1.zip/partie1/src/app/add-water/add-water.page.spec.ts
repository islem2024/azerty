import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddWaterPage } from './add-water.page';

describe('AddWaterPage', () => {
  let component: AddWaterPage;
  let fixture: ComponentFixture<AddWaterPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(AddWaterPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
