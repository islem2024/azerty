import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastController, AlertController } from '@ionic/angular';
import { formatDate } from '@angular/common';
import { IonHeader, IonButtons, IonTitle, IonBackButton, IonToolbar, IonContent, IonIcon, IonItem, IonLabel, IonText, IonButton, IonSpinner, IonCard, IonCardContent, IonInput, IonTextarea, IonDatetime } from "@ionic/angular/standalone";
import { addIcons } from 'ionicons';
import { waterOutline, medkitOutline, restaurantOutline, cafeOutline, shirtOutline, leafOutline, addCircleOutline } from 'ionicons/icons';
import { IonicModule } from '@ionic/angular';
import { HttpClientModule } from '@angular/common/http';
import { ConsommationEauService,ConsommationEau } from '../services/ConsommationEauService';
import { AuthService } from '../services/auth.services';
import { JwtHelperService } from '@auth0/angular-jwt';
import { SettingsService } from '../services/SettingsService';

@Component({
  selector: 'app-add-water',
  templateUrl: './add-water.page.html',
  styleUrls: ['./add-water.page.scss'],
  standalone: true,
  imports: [
    IonicModule,
    CommonModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [ConsommationEauService, AuthService,SettingsService]
})
export class AddWaterPage implements OnInit {
  consomationForm!: FormGroup;
  isSubmitting = false;
  currentDate = new Date();
  waterUnit: string = 'litres'; // Default unit
  private jwtHelper: JwtHelperService = new JwtHelperService();

  waterCategories = [
    { name: 'Douche', icon: 'water-outline' },
    { name: 'Toilettes', icon: 'medkit-outline' },
    { name: 'Cuisine', icon: 'restaurant-outline' },
    { name: 'Vaisselle', icon: 'cafe-outline' },
    { name: 'Lessive', icon: 'shirt-outline' },
    { name: 'Jardin', icon: 'leaf-outline' },
    { name: 'Autre', icon: 'add-circle-outline' }
  ];

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private toastController: ToastController,
    private alertController: AlertController,
    private consomationService: ConsommationEauService,
    private authService: AuthService,
    private settingsService: SettingsService
  ) {
    this.consomationForm = this.formBuilder.group({
      value: ['', [Validators.required, Validators.min(0.1)]],
      prix: ['', [Validators.required]],
      category: ['', Validators.required],
      date: [formatDate(this.currentDate, 'yyyy-MM-dd', 'en'), Validators.required],
      notes: ['']
    });

    addIcons({
      'water-outline': waterOutline,
      'medkit-outline': medkitOutline,
      'restaurant-outline': restaurantOutline,
      'cafe-outline': cafeOutline,
      'shirt-outline': shirtOutline,
      'leaf-outline': leafOutline,
      'add-circle-outline': addCircleOutline
    });
  }

  ngOnInit(): void {
    // Load water unit from settings
    this.settingsService.getSettings().subscribe(settings => {
      this.waterUnit = settings.waterUnit || 'litres';
    });
    console.log('AddWaterPage initialisée');
  }

  get title() {
    return "Ajouter consommation d'eau";
  }

  get unit() {
    return this.waterUnit === 'litres' ? 'L' : 'm³';
  }

  get categories() {
    return this.waterCategories;
  }

  selectCategory(category: string) {
    this.consomationForm.get('category')?.setValue(category);
  }

  submitForm() {
    if (this.consomationForm.valid) {
      this.isSubmitting = true;

      const token = this.authService.getToken();
      if (!token) {
        this.isSubmitting = false;
        this.presentToast('Aucun token trouvé. Veuillez vous connecter.', 'danger');
        this.router.navigate(['/loginpage']);
        return;
      }

      const decoded = this.jwtHelper.decodeToken(token);
      const currentTimestamp = Math.floor(Date.now() / 1000);
      const expTimestamp = decoded.exp;
      const isExpired = currentTimestamp > expTimestamp;

      if (isExpired || this.jwtHelper.isTokenExpired(token)) {
        this.isSubmitting = false;
        this.presentToast('Session expirée. Veuillez vous reconnecter.', 'danger');
        this.router.navigate(['/loginpage']);
        return;
      }

      const userId = this.authService.getCurrentUserId();
      if (!userId) {
        this.isSubmitting = false;
        this.presentToast('Impossible d\'identifier l\'utilisateur. Veuillez vous reconnecter.', 'danger');
        this.router.navigate(['/loginpage']);
        return;
      }

      // Convert value to litres if unit is m³
      const value = this.waterUnit === 'm3' ? this.consomationForm.value.value * 1000 : this.consomationForm.value.value;

      const consommationData = {
        value: value,
        prix: this.consomationForm.value.prix,
        category: this.consomationForm.value.category,
        date: this.consomationForm.value.date,
        notes: this.consomationForm.value.notes,
        userId: userId
      };

      this.consomationService.addConsommationEau(consommationData)
        .subscribe({
          next: (response: ConsommationEau) => {
            this.isSubmitting = false;
            this.presentToast('Consommation d\'eau enregistrée avec succès!', 'success');
            this.router.navigate(['/water-dashboard-page']);
          },
          error: (error) => {
            this.isSubmitting = false;
            let errorMessage = 'Erreur lors de l\'enregistrement. Veuillez réessayer.';
            if (error.status === 403) {
              errorMessage = 'Accès refusé. Veuillez vous connecter à nouveau.';
              this.authService.logout();
              this.router.navigate(['/loginpage']);
            } else if (error.status === 0) {
              errorMessage = 'Erreur de connexion au serveur. Vérifiez votre réseau.';
            }
            this.presentToast(errorMessage, 'danger');
            console.error('Erreur:', error);
          }
        });
    } else {
      this.markFormGroupTouched(this.consomationForm);
      this.presentToast('Veuillez remplir tous les champs obligatoires.', 'warning');
    }
  }

  markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: color,
      position: 'bottom'
    });
    await toast.present();
  }
}