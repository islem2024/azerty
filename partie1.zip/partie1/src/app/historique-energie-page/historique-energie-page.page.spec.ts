import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HistoriqueEnergiePagePage } from './historique-energie-page.page';

describe('HistoriqueEnergiePagePage', () => {
  let component: HistoriqueEnergiePagePage;
  let fixture: ComponentFixture<HistoriqueEnergiePagePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoriqueEnergiePagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
