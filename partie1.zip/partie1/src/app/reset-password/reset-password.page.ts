import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.services';
import { Router, ActivatedRoute } from '@angular/router';
import { IonicModule, ToastController } from '@ionic/angular';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.page.html',
  styleUrls: ['./reset-password.page.scss'],
  standalone: true,
  imports: [IonicModule, ReactiveFormsModule, CommonModule],
})
export class ResetPasswordPage implements OnInit {
  resetPasswordForm: FormGroup;
  email: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private toastController: ToastController
  ) {
    this.resetPasswordForm = this.fb.group({
      resetCode: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  ngOnInit() {
    this.email = this.route.snapshot.queryParamMap.get('email');
    if (!this.email) {
      this.router.navigate(['/forgot-password']);
    }
  }

  async resetPassword() {
    if (this.resetPasswordForm.valid && this.email) {
      const { resetCode, newPassword } = this.resetPasswordForm.value;
      this.authService.resetPassword(this.email, resetCode, newPassword).subscribe({
        next: async () => {
          const toast = await this.toastController.create({
            message: 'Mot de passe réinitialisé avec succès.',
            duration: 3000,
            color: 'success',
          });
          await toast.present();
          this.router.navigate(['/loginpage']);
        },
        error: async (err) => {
          const errorMsg = err.error?.message || 'Erreur lors de la réinitialisation du mot de passe.';
          const toast = await this.toastController.create({
            message: errorMsg,
            duration: 3000,
            color: 'danger',
          });
          await toast.present();
        },
      });
    }
  }
}