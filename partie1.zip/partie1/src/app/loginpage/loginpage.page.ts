import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import {IonHeader, IonTitle, IonToolbar, IonBackButton, IonImg, IonItem, IonLabel, IonInput, IonButton, IonIcon, IonContent, IonCard, IonCardContent, IonButtons } from '@ionic/angular/standalone';
import {RouterModule } from '@angular/router';
import { addIcons } from 'ionicons';
import { arrowBackOutline } from 'ionicons/icons';
import { AuthService } from '../services/auth.services';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { th } from 'date-fns/locale';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.page.html',
  styleUrls: ['./loginpage.page.scss'],
  standalone: true,
  imports: [ReactiveFormsModule,IonButtons, HttpClientModule,RouterModule,IonHeader,IonTitle,IonToolbar ,IonCardContent, IonCard, IonContent, IonButton, IonInput, IonLabel, IonItem, CommonModule, FormsModule,IonBackButton],
  providers: [AuthService]
})
export class LoginPage { 
  loginForm: FormGroup;
   
   
    constructor(private authService: AuthService,private router: Router,
      private fb:FormBuilder){
      this.loginForm =this.fb.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]],
      })






      addIcons({arrowBackOutline:'arrowBackOutline'});
    }
    
    login() {
      console.log('Sending login request:', this.loginForm.value);
      
      this.authService.login(this.loginForm.value.email, this.loginForm.value.password)
        .subscribe({
          next: (response) => {
            console.log('Login successful, response:', response);
            this.router.navigate(['/dashboard']);
          },
          error: (err) => {
            console.error('Login failed, complete error:', err);
            // Check the exact error message from your backend
            const errorMsg = err.error?.message || 'Email ou mot de passe incorrect';
            alert(errorMsg);
          }
        });
    }
  
    
    
    
    
      }
  




