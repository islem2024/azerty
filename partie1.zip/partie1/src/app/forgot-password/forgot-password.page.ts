import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.services';
import { Router } from '@angular/router';
import { IonicModule, ToastController } from '@ionic/angular';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.page.html',
  styleUrls: ['./forgot-password.page.scss'],
  standalone: true,
  imports: [IonicModule, ReactiveFormsModule, CommonModule],
})
export class ForgotPasswordPage {
  forgotPasswordForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private toastController: ToastController
  ) {
    this.forgotPasswordForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
    });
  }

  async requestPasswordReset() {
    if (this.forgotPasswordForm.valid) {
      const email = this.forgotPasswordForm.value.email;
      this.authService.requestPasswordReset(email).subscribe({
        next: async () => {
          const toast = await this.toastController.create({
            message: 'Un code de réinitialisation a été envoyé à votre email.',
            duration: 3000,
            color: 'success',
          });
          await toast.present();
          this.router.navigate(['/reset-password'], { queryParams: { email } });
        },
        error: async (err) => {
          const errorMsg = err.error?.message || 'Erreur lors de la demande de réinitialisation.';
          const toast = await this.toastController.create({
            message: errorMsg,
            duration: 3000,
            color: 'danger',
          });
          await toast.present();
        },
      });
    }
  }
}