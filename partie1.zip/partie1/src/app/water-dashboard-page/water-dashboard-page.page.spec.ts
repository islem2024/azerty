import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WaterDashboardPagePage } from './water-dashboard-page.page';

describe('WaterDashboardPagePage', () => {
  let component: WaterDashboardPagePage;
  let fixture: ComponentFixture<WaterDashboardPagePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(WaterDashboardPagePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
