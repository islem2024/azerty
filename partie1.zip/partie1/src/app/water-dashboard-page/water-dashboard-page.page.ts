import { Component, OnInit, ViewChild, AfterViewInit, ElementRef, LOCALE_ID, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { ConsommationEauService,ConsommationEau } from '../services/ConsommationEauService';
import { AuthService } from '../services/auth.services';
import { Chart, registerables } from 'chart.js';
import { IonSegment, IonSegmentButton, IonLabel, IonContent, IonCard, IonCardContent, IonButton, IonHeader, IonToolbar, IonTitle, IonItem, IonInput, IonSelect, IonSelectOption, IonDatetime, IonTextarea, IonSpinner } from '@ionic/angular/standalone';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { JwtHelperService } from '@auth0/angular-jwt';
import { ToastController, AlertController } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { pencilOutline, trashOutline, closeOutline } from 'ionicons/icons';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { registerLocaleData } from '@angular/common';
import { SettingsService } from '../services/SettingsService';
import localeFr from '@angular/common/locales/fr';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// Register the French locale
registerLocaleData(localeFr, 'fr-FR');
Chart.register(...registerables);

@Component({
  selector: 'app-water-dashboard-page',
  templateUrl: './water-dashboard-page.page.html',
  styleUrls: ['./water-dashboard-page.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, ReactiveFormsModule, FormsModule, HttpClientModule],
  providers: [
    ConsommationEauService,
    AuthService,SettingsService,
    { provide: LOCALE_ID, useValue: 'fr-FR' }
  ]
})
export class WaterDashboardPagePage implements OnInit, AfterViewInit {
  @ViewChild('lineChartCanvas', { static: false }) lineChartCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('barChartCanvas', { static: false }) barChartCanvas!: ElementRef<HTMLCanvasElement>;
  @ViewChild('priceChartCanvas', { static: false }) priceChartCanvas!: ElementRef<HTMLCanvasElement>; // New canvas for price
  @ViewChild('editModal') editModal: any;
  @ViewChild('dashboardContent', { static: false }) dashboardContent!: ElementRef;
  @ViewChild('pdfContent', { static: false }) pdfContent!: ElementRef;

  selectedPeriod: string = 'daily';
  consumptionByPeriod: any = {};
  priceByPeriod: any = {}; // New property for price data
  categoryBreakdown: any = {};
  stats: any = { total: 0, average: 0 };
  lineChart: Chart | undefined;
  barChart: Chart | undefined;
  priceChart: Chart | undefined; // New chart instance for price
  isLoading = false;
  isSubmitting = false;
  entries: ConsommationEau[] = [];
  selectedEntry: ConsommationEau| null = null;
  editForm: FormGroup;
  waterUnit: string = 'kWh'; // Default unit
  private jwtHelper: JwtHelperService = new JwtHelperService();

  constructor(
    private consommationService: ConsommationEauService,
    private authService: AuthService,
    private settingsService: SettingsService,
    private toastController: ToastController,
    private alertController: AlertController,
    private router: Router,
    private formBuilder: FormBuilder,
    private cdr: ChangeDetectorRef
  ) {
    this.editForm = this.formBuilder.group({
      id: [''],
      value: ['', [Validators.required, Validators.min(0.1)]],
      prix: ['', [Validators.required, Validators.min(0)]],
      category: ['', Validators.required],
      date: ['', Validators.required],
      notes: ['']
    });

    addIcons({
      'pencil-outline': pencilOutline,
      'trash-outline': trashOutline,
      'close-outline': closeOutline
    });
  }

  ngOnInit() {
    if (!this.authService.isAuthenticated()) {
      this.presentToast('Session expirée. Veuillez vous reconnecter.', 'warning');
      this.router.navigate(['/login']);
      return;
    }
    // Load energy unit from settings
    this.settingsService.getSettings().subscribe(settings => {
      this.waterUnit = settings.waterUnit|| 'L';
      this.updateCharts(); // Update charts when unit changes
    });
    this.loadData('daily');
    this.loadEntries();
  }

  ngAfterViewInit() {
    this.tryUpdateCharts();
  }

  tryUpdateCharts(retries: number = 5) {
    this.cdr.detectChanges();
    if (this.lineChartCanvas?.nativeElement && this.barChartCanvas?.nativeElement && this.priceChartCanvas?.nativeElement) {
      this.updateCharts();
    } else if (retries > 0) {
      console.warn('Canvas not ready yet, retrying...', retries);
      setTimeout(() => this.tryUpdateCharts(retries - 1), 500);
    } else {
      console.error('Canvas elements not found after multiple retries');
      this.presentToast('Erreur : les éléments du tableau de bord ne sont pas disponibles.', 'danger');
    }
  }

  segmentChanged(event: any) {
    this.selectedPeriod = event.detail.value;
    this.loadData(this.selectedPeriod);
  }

  loadData(period: string) {
    this.isLoading = true;
    const today = new Date();
    let startDate: string;
    let endDate: string = today.toISOString().split('T')[0];

    if (period === 'daily') {
      startDate = new Date(today.setDate(today.getDate() - 7)).toISOString().split('T')[0];
    } else if (period === 'weekly') {
      startDate = new Date(today.setDate(today.getDate() - 30)).toISOString().split('T')[0];
    } else {
      startDate = new Date(today.setFullYear(today.getFullYear() - 1)).toISOString().split('T')[0];
    }

    this.consommationService.getStats(period, startDate, endDate).subscribe({
      next: (response) => {
        this.consumptionByPeriod = response.consumptionByPeriod || {};
        this.priceByPeriod = response.priceByPeriod || {}; // Load price data
        this.categoryBreakdown = response.categoryBreakdown || {};
        this.stats = response.stats || { total: 0, average: 0 };
        // Convert stats if unit is W
        if (this.waterUnit === 'W') {
          this.stats.total = this.stats.total * 1000;
          this.stats.average = this.stats.average * 1000;
        }
        this.isLoading = false;
        this.cdr.detectChanges();
        this.updateCharts();
      },
      error: (error) => {
        console.error('Error fetching stats:', error);
        this.presentToast('Erreur lors du chargement des données.', 'danger');
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  loadEntries() {
    this.isLoading = true;
    this.consommationService.getAllConsommations().subscribe({
      next: (entries) => {
        this.entries = entries.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(entry => ({
          ...entry,
          value: this.waterUnit === 'm³' ? entry.value * 1000 : entry.value
        }));
        this.isLoading = false;
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error fetching entries:', error);
        this.presentToast('Erreur lors du chargement des entrées.', 'danger');
        this.isLoading = false;
        this.cdr.detectChanges();
      }
    });
  }

  openEditModal(entry: ConsommationEau) {
    this.selectedEntry = entry;
    this.editForm.patchValue({
      id: entry.id,
      value: entry.value, // Already converted in loadEntries
      prix: entry.prix,
      category: entry.category,
      date: entry.date,
      notes: entry.notes
    });
    this.editModal.present();
  }

  async updateEntry() {
    if (this.editForm.valid) {
      this.isSubmitting = true;
      const updatedData = this.editForm.value;

      // Convert value to kWh if unit is W
      updatedData.value = this.waterUnit === 'm³' ? updatedData.value / 1000 : updatedData.value;

      this.consommationService.updateConsommationEau(updatedData.id, updatedData).subscribe({
        next: () => {
          this.isSubmitting = false;
          this.presentToast('Entrée mise à jour avec succès!', 'success');
          this.editModal.dismiss();
          this.loadData(this.selectedPeriod);
          this.loadEntries();
        },
        error: (error) => {
          this.isSubmitting = false;
          this.presentToast('Erreur lors de la mise à jour.', 'danger');
          console.error('Erreur:', error);
        }
      });
    } else {
      this.presentToast('Veuillez remplir tous les champs obligatoires.', 'warning');
    }
  }

  async deleteEntry(id: number) {
    const alert = await this.alertController.create({
      header: 'Confirmer la suppression',
      message: 'Êtes-vous sûr de vouloir supprimer cette entrée ?',
      buttons: [
        { text: 'Annuler', role: 'cancel' },
        {
          text: 'Supprimer',
          handler: () => {
            this.consommationService.deleteConsommationEau(id).subscribe({
              next: () => {
                this.presentToast('Entrée supprimée avec succès!', 'success');
                this.loadData(this.selectedPeriod);
                this.loadEntries();
              },
              error: (error) => {
                this.presentToast('Erreur lors de la suppression.', 'danger');
                console.error('Erreur:', error);
              }
            });
          }
        }
      ]
    });

    await alert.present();
  }

  navigateToAddWater() {
    this.router.navigate(['/add-water']);
  }

  async presentToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      color: color,
      position: 'bottom'
    });
    await toast.present();
  }

  async downloadPDF() {
    if (!this.pdfContent || !this.pdfContent.nativeElement) {
      console.error('pdfContent is not defined or not ready');
      this.presentToast('Erreur : Contenu du tableau de bord non disponible.', 'danger');
      return;
    }

    if (this.lineChart) this.lineChart.update();
    if (this.barChart) this.barChart.update();
    if (this.priceChart) this.priceChart.update(); // Update price chart

    const pdfElement = this.pdfContent.nativeElement;

    await new Promise(resolve => setTimeout(resolve, 500));

    try {
      const canvas = await html2canvas(pdfElement, {
        scale: 2,
        useCORS: true,
        logging: true,
        backgroundColor: '#f5f5f5',
        scrollY: -window.scrollY,
        windowHeight: pdfElement.scrollHeight
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');

      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('tableau-de-bord-energie.pdf');
    } catch (error) {
      console.error('Erreur lors de la génération du PDF :', error);
      this.presentToast('Erreur lors de la génération du PDF.', 'danger');
    }
  }

  updateCharts() {
    if (!this.lineChartCanvas?.nativeElement || !this.barChartCanvas?.nativeElement || !this.priceChartCanvas?.nativeElement) {
      console.warn("Les canvas ne sont pas encore prêts pour les graphiques.");
      return;
    }

    // Destroy existing charts
    if (this.lineChart) this.lineChart.destroy();
    if (this.barChart) this.barChart.destroy();
    if (this.priceChart) this.priceChart.destroy();

    // Energy Consumption Line Chart
    const consumptionLabels = Object.keys(this.consumptionByPeriod).sort();
    const consumptionValues = consumptionLabels.map(label => {
      const value = this.consumptionByPeriod[label] || 0;
      return this.waterUnit === 'm³' ? value * 1000 : value;
    });

    this.lineChart = new Chart(this.lineChartCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: consumptionLabels.length ? consumptionLabels.map(label => {
          if (this.selectedPeriod === 'daily') {
            const date = new Date(label);
            return date.toLocaleDateString('fr-FR', { weekday: 'short' });
          } else if (this.selectedPeriod === 'weekly') {
            const date = new Date(label);
            return `Sem. ${date.toLocaleDateString('fr-FR', { month: 'short', day: 'numeric' })}`;
          } else {
            const [year, month] = label.split('-');
            const date = new Date(parseInt(year), parseInt(month) - 1);
            return date.toLocaleDateString('fr-FR', { month: 'short' });
          }
        }) : ['Aucune donnée'],
        datasets: [{
          label: `Consommation d'énergie (${this.waterUnit})`,
          data: consumptionValues.length ? consumptionValues : [0],
          borderColor: '#007bff',
          backgroundColor: 'rgba(0, 123, 255, 0.1)',
          fill: true,
          tension: 0.1
        }]
      },
      options: {
        plugins: { tooltip: { enabled: true } },
        scales: {
          y: {
            beginAtZero: true,
            suggestedMax: consumptionValues.length ? Math.max(...consumptionValues) * 1.1 : 100
          }
        }
      }
    });

    // Price Line Chart
    const priceLabels = Object.keys(this.priceByPeriod).sort();
    const priceValues = priceLabels.map(label => this.priceByPeriod[label] || 0);

    this.priceChart = new Chart(this.priceChartCanvas.nativeElement, {
      type: 'line',
      data: {
        labels: priceLabels.length ? priceLabels.map(label => {
          if (this.selectedPeriod === 'daily') {
            const date = new Date(label);
            return date.toLocaleDateString('fr-FR', { weekday: 'short' });
          } else if (this.selectedPeriod === 'weekly') {
            const date = new Date(label);
            return `Sem. ${date.toLocaleDateString('fr-FR', { month: 'short', day: 'numeric' })}`;
          } else {
            const [year, month] = label.split('-');
            const date = new Date(parseInt(year), parseInt(month) - 1);
            return date.toLocaleDateString('fr-FR', { month: 'short' });
          }
        }) : ['Aucune donnée'],
        datasets: [{
          label: 'Coût de l\'énergie (TND)',
          data: priceValues.length ? priceValues : [0],
          borderColor: '#28a745',
          backgroundColor: 'rgba(40, 167, 69, 0.1)',
          fill: true,
          tension: 0.1
        }]
      },
      options: {
        plugins: { tooltip: { enabled: true } },
        scales: {
          y: {
            beginAtZero: true,
            suggestedMax: priceValues.length ? Math.max(...priceValues) * 1.1 : 100
          }
        }
      }
    });

    // Bar Chart for Category Breakdown
    const categories = Object.keys(this.categoryBreakdown);
    const percentages = categories.map(category => this.categoryBreakdown[category] || 0);

    this.barChart = new Chart(this.barChartCanvas.nativeElement, {
      type: 'bar',
      data: {
        labels: categories.length ? categories : ['Aucune donnée'],
        datasets: [{
          label: 'Répartition par usage (%)',
          data: percentages.length ? percentages : [0],
          backgroundColor: ['#007bff', '#28a745', '#dc3545', '#ffc107', '#17a2b8']
        }]
      },
      options: {
        indexAxis: 'y',
        plugins: { tooltip: { enabled: true } },
        scales: { x: { beginAtZero: true, max: 100 } }
      }
    });
  }
}
